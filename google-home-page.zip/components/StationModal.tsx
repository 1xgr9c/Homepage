
import React, { useState, useEffect } from 'react';
import { LinkItem } from '../types';

interface StationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (item: LinkItem) => void;
  editingItem?: LinkItem | null;
}

export const StationModal: React.FC<StationModalProps> = ({ isOpen, onClose, onConfirm, editingItem }) => {
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [tracklist, setTracklist] = useState('');
  const [streamUrl, setStreamUrl] = useState('');

  useEffect(() => {
    if (editingItem) {
      setName(editingItem.name);
      setUrl(editingItem.url);
      setTracklist(editingItem.tracklistUrl || '');
      setStreamUrl(editingItem.streamUrl || '');
    } else {
      setName('');
      setUrl('');
      setTracklist('');
      setStreamUrl('');
    }
  }, [editingItem, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !url) return;

    let domain = '';
    try {
      domain = new URL(url.startsWith('http') ? url : `https://${url}`).hostname;
    } catch {
      domain = url;
    }

    onConfirm({
      id: editingItem?.id || Date.now().toString(),
      name,
      url: url.startsWith('http') ? url : `https://${url}`,
      tracklistUrl: tracklist ? (tracklist.startsWith('http') ? tracklist : `https://${tracklist}`) : undefined,
      streamUrl: streamUrl ? (streamUrl.startsWith('http') ? streamUrl : `https://${streamUrl}`) : undefined,
      domain,
    });
    
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-white/90 backdrop-blur-md flex items-center justify-center z-50 p-4">
      <div className="bg-white border border-gray-100 shadow-2xl rounded-3xl w-full max-w-md p-8 animate-in fade-in zoom-in duration-200">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-sm font-bold uppercase tracking-widest text-black">
            {editingItem ? 'Edit Station' : 'Add Station'}
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-black transition-colors p-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-[10px] uppercase tracking-widest text-gray-500 font-bold mb-1">Station Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border-b-2 border-gray-100 py-2 focus:border-black outline-none transition-colors text-sm font-medium"
              placeholder="e.g. Worldwide FM"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] uppercase tracking-widest text-gray-500 font-bold mb-1">Website URL</label>
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-full border-b-2 border-gray-100 py-2 focus:border-black outline-none transition-colors text-sm font-medium"
              placeholder="worldwidefm.net"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] uppercase tracking-widest text-gray-500 font-bold mb-1">Direct Stream URL</label>
            <input
              type="text"
              value={streamUrl}
              onChange={(e) => setStreamUrl(e.target.value)}
              className="w-full border-b-2 border-gray-100 py-2 focus:border-black outline-none transition-colors text-sm font-medium"
              placeholder="stream.worldwidefm.net/live"
            />
          </div>
          <div>
            <label className="block text-[10px] uppercase tracking-widest text-gray-500 font-bold mb-1">Tracklist URL (Optional)</label>
            <input
              type="text"
              value={tracklist}
              onChange={(e) => setTracklist(e.target.value)}
              className="w-full border-b-2 border-gray-100 py-2 focus:border-black outline-none transition-colors text-sm font-medium"
              placeholder="worldwidefm.net/schedule"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-black text-white text-[11px] uppercase tracking-[0.2em] py-4 rounded-xl hover:bg-gray-800 transition-all font-bold shadow-lg active:scale-95"
          >
            {editingItem ? 'Save Changes' : 'Confirm'}
          </button>
        </form>
      </div>
    </div>
  );
};
