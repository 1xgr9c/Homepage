
import React from 'react';
import { LinkItem } from '../types';

interface GridItemProps {
  item: LinkItem;
  onRemove?: (id: string) => void;
  onEdit?: (item: LinkItem) => void;
  isEditable?: boolean;
  isPlaying?: boolean;
  onTogglePlay?: (item: LinkItem) => void;
}

export const GridItem: React.FC<GridItemProps> = ({ 
  item, 
  onRemove, 
  onEdit,
  isEditable, 
  isPlaying, 
  onTogglePlay 
}) => {
  const faviconUrl = `https://www.google.com/s2/favicons?domain=${item.domain}&sz=128`;

  const handlePlayClick = (e: React.MouseEvent) => {
    if (onTogglePlay && item.streamUrl) {
      e.preventDefault();
      onTogglePlay(item);
    }
  };

  return (
    <div className="group relative flex flex-col items-center transition-all duration-300 w-full">
      <div className="relative flex flex-col items-center gap-2 w-full">
        {/* Thumbnail / Play Button Area */}
        <div 
          onClick={handlePlayClick}
          className={`relative w-14 h-14 md:w-16 md:h-16 bg-white rounded-xl shadow-sm border border-gray-200 flex items-center justify-center overflow-hidden transition-all duration-300 ${item.streamUrl ? 'cursor-pointer' : ''} ${isPlaying ? 'ring-1 ring-black scale-105' : 'group-hover:scale-105 group-hover:border-gray-300'}`}
        >
          <img
            src={faviconUrl}
            alt={item.name}
            className={`w-6 h-6 md:w-8 md:h-8 transition-all duration-300 ${isPlaying ? 'scale-75 opacity-20' : 'opacity-100'}`}
            onError={(e) => {
              (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${item.name}&background=f3f4f6&color=1a1a1a&size=128&bold=true`;
            }}
          />
          
          {/* Play/Pause Overlay */}
          {item.streamUrl && (
            <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${isPlaying ? 'opacity-100' : 'opacity-0 group-hover:opacity-100 bg-black/5'}`}>
              {isPlaying ? (
                <div className="flex items-center gap-1">
                  <span className="w-1 h-1 bg-black rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
                  <span className="w-1 h-1 bg-black rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                  <span className="w-1 h-1 bg-black rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
                </div>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-black" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                </svg>
              )}
            </div>
          )}
        </div>

        {/* Name Link */}
        <a
          href={item.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-[10px] md:text-[11px] font-bold text-gray-900 hover:text-black transition-colors uppercase tracking-widest text-center px-1 whitespace-nowrap overflow-hidden text-ellipsis max-w-full"
        >
          {item.name}
        </a>
      </div>

      {/* Tracklist Link */}
      {item.tracklistUrl && (
        <a
          href={item.tracklistUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-[8px] uppercase tracking-tighter text-gray-800 hover:text-black hover:underline transition-all mt-0.5"
        >
          Tracklist
        </a>
      )}

      {/* Actions */}
      {isEditable && (
        <div className="absolute -top-1 -right-1 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
          {onRemove && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRemove(item.id);
              }}
              className="bg-white border border-gray-200 text-gray-400 hover:text-red-600 rounded-full w-5 h-5 flex items-center justify-center shadow-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
          {onEdit && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onEdit(item);
              }}
              className="bg-white border border-gray-200 text-gray-400 hover:text-black rounded-full w-5 h-5 flex items-center justify-center shadow-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-2.5 w-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
              </svg>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
